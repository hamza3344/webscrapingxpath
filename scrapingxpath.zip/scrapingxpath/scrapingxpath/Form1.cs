﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace scrapingxpath
{
    public partial class Form1 : Form
    {
        HtmlAgilityPack.HtmlWeb web = new HtmlAgilityPack.HtmlWeb();
        HtmlAgilityPack.HtmlDocument doc;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            doc = web.Load("http://example.python-scraping.com/places/default/view/Anguilla-8");
            simplescraper("//*[@id=\"places_country_or_district__row\"]/td[2]");
            doc = web.Load("https://en.wikipedia.org/wiki/Web_scraping");
            simplescraper("/html/body/div[3]/div[3]/div[5]/div[1]/p");

        }
        public void simplescraper(string s)
        {
            var tags = doc.DocumentNode.SelectNodes(s).Take(5);
            foreach(var tag in tags)
            {
                MessageBox.Show(tag.InnerText);
            }
        }
    }
}
